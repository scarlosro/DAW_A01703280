SELECT *
FROM Materiales