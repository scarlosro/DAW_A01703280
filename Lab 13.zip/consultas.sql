  ALTER TABLE Materiales add constraint llaveMateriales PRIMARY KEY (Clave)

  INSERT INTO Materiales values(1000, 'xxx', 1000)

  sp_helpconstraint materiales

  ALTER TABLE Proveedores add constraint llaveProveedores PRIMARY KEY (RFC)
  ALTER TABLE Proyectos add constraint llaveProyectos PRIMARY KEY (Numero)
  ALTER TABLE Entregan add constraint llaveEntregan PRIMARY KEY (Clave, RFC, Numero, Fecha)

  SELECT * from Materiales ;
  SELECT * from Proyectos ;
  SELECT * from Proveedores ;

  INSERT INTO entregan values (0, 'xxx', 0, '1-jan-02', 0) ;

  Delete from Entregan where Clave = 0

  ALTER TABLE entregan add constraint cfentreganclave
  foreign key (clave) references materiales(clave);

  Delete from Entregan where Clave = 0
  
  ALTER TABLE entregan add constraint cfentregannum
  foreign key (Numero) references proyectos(Numero);

sp_helpconstraint Materiales

  ALTER TABLE entregan add constraint cfentreganrfc
  foreign key (RFC) references Proveedores(RFC);

ALTER TABLE Proyectos add constraint llaveProyectos PRIMARY KEY (RFC)

 ALTER TABLE entregan add constraint cfentreganRFC foreign key (RFC) references proveedores(RFC)
 
   INSERT INTO Materiales values(1000, 'xxx', 1000)

  sp_helpconstraint materiales

 INSERT INTO entregan values (1000, 'AAAA800101', 5000, GETDATE(), 0);

DELETE 
FROM Entregan
Where Cantidad=0

 ALTER TABLE entregan add constraint cantidad check (cantidad > 0) ;
INSERT INTO entregan values (1000, 'AAAA800101', 5000, GETDATE(), 0);